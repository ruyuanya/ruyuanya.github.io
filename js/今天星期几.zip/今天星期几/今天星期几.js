import plugin from '../../lib/plugins/plugin.js';

// by：如愿(2368635993)
// 最近编写于？emmm忘了.
export class wygn extends plugin {
    constructor() {
        super({
            name: '今天星期几',
            dsc: '这是什么，为什么要我写.',
            event: 'message',
            priority: 1145,
            rule: [
                {
                    reg: /^#?今天(星期|周)几$/i,
                    fnc: 'xqj',
                }
            ]
        })
    }
    async xqj(e) {
        let today = new Date()
        let weekday = today.getDay();
        // 可以自己换其他图片
        let weekdayImages = {
            "0": "./resources/weekdayimage/0.jpg", // 星期日 
            "1": "./resources/weekdayimage/1.jpg", // 星期一 
            "2": "./resources/weekdayimage/2.jpg", // 星期二  
            "3": "./resources/weekdayimage/3.jpg", // 星期三  
            "4": "./resources/weekdayimage/4.jpg", // 星期四 
            "5": "./resources/weekdayimage/5.jpg", // 星期  
            "6": "./resources/weekdayimage/6.jpg" // 星期六 
        };
        let weekimage = weekdayImages[weekday]
        let weekdayText = ["日", "一", "二", "三", "四", "五", "六"]
        let todayWeekday = weekdayText[weekday]
        if (e.isMaster) {
            await this.reply([`主人~今天『星期${todayWeekday}』哦~`, segment.image(weekimage)], true)
        } else {
            await this.reply([`憨憨~今天『星期${todayWeekday}』哦~`, segment.image(weekimage)], true)
        }
        return true
    }
}